import React, { useEffect, useState } from 'react';
import { io } from 'socket.io-client';
import { School, User, LogOut, Settings, Users, Shield, Phone, CheckCircle, ArrowLeft } from 'lucide-react';

const socket = io();

export default function App() {
  const [currentSchool, setCurrentSchool] = useState<any>(null);
  const [schoolNameInput, setSchoolNameInput] = useState('');
  const [isCheckingSchool, setIsCheckingSchool] = useState(false);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [error, setError] = useState('');

  const handleCheckSchool = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCheckingSchool(true);
    setError('');
    try {
      const res = await fetch('/api/school/check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: schoolNameInput }),
      });
      const data = await res.json();
      setIsCheckingSchool(false);
      
      if (data.exists) {
        setCurrentSchool(data.school);
        setNeedsSetup(false);
      } else {
        setNeedsSetup(true);
      }
    } catch (error) {
      setIsCheckingSchool(false);
      setError('Network error. Please try again.');
    }
  };

  if (!currentSchool && !needsSetup) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-md">
          <div className="flex justify-center mb-6">
            <div className="w-16 h-16 bg-indigo-100 text-indigo-600 flex items-center justify-center rounded-full">
              <School size={32} />
            </div>
          </div>
          <h2 className="text-2xl font-bold text-center mb-2">Find Your School</h2>
          <p className="text-gray-500 text-center mb-6">Enter your school name to continue</p>
          
          {error && <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-4">{error}</div>}
          
          <form onSubmit={handleCheckSchool} className="space-y-4">
            <div>
              <input type="text" required placeholder="School Name" value={schoolNameInput} onChange={(e) => setSchoolNameInput(e.target.value)} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
            </div>
            <button type="submit" disabled={isCheckingSchool} className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition font-medium disabled:opacity-50">
              {isCheckingSchool ? 'Checking...' : 'Continue'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (needsSetup) {
    return <SetupAdmin schoolName={schoolNameInput} onSetupComplete={(school) => {
      setCurrentSchool(school);
      setNeedsSetup(false);
    }} onCancel={() => setNeedsSetup(false)} />;
  }

  if (!user) {
    return <Login onLogin={setUser} school={currentSchool} onBack={() => setCurrentSchool(null)} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="bg-white shadow-sm px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          {currentSchool.logo_url ? (
            <img src={currentSchool.logo_url} alt="Logo" className="w-10 h-10 object-contain rounded-md" />
          ) : (
            <div className="w-10 h-10 bg-indigo-100 text-indigo-600 flex items-center justify-center rounded-md">
              <School size={24} />
            </div>
          )}
          <h1 className="text-xl font-semibold">{currentSchool.name}</h1>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-sm text-gray-500 capitalize">{user.role}</span>
          <button onClick={() => setUser(null)} className="text-gray-400 hover:text-gray-600">
            <LogOut size={20} />
          </button>
        </div>
      </header>

      <main className="max-w-4xl mx-auto p-6">
        {user.role === 'admin' && <AdminDashboard school={currentSchool} setSchool={setCurrentSchool} user={user} />}
        {user.role === 'parent' && <ParentDashboard user={user} school={currentSchool} />}
        {user.role === 'guard' && <GuardDashboard school={currentSchool} />}
      </main>
    </div>
  );
}

function SetupAdmin({ schoolName, onSetupComplete, onCancel }: { schoolName: string, onSetupComplete: (school: any) => void, onCancel: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [enrollmentCode, setEnrollmentCode] = useState('');
  const [error, setError] = useState('');

  const handleSetup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await fetch('/api/school/setup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ schoolName, email, password, enrollmentCode }),
      });
      if (res.ok) {
        const data = await res.json();
        onSetupComplete(data.school);
      } else {
        const data = await res.json();
        setError(data.error || 'Failed to setup school');
      }
    } catch (error) {
      setError('Network error. Please try again.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-md">
        <button onClick={onCancel} className="text-gray-400 hover:text-gray-600 mb-4 flex items-center gap-1 text-sm">
          <ArrowLeft size={16} /> Back
        </button>
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-indigo-100 text-indigo-600 flex items-center justify-center rounded-full">
            <Settings size={32} />
          </div>
        </div>
        <h2 className="text-2xl font-bold text-center mb-2">Setup New School</h2>
        <p className="text-gray-500 text-center mb-6">Create the admin account for <strong>{schoolName}</strong>.</p>
        
        {error && <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-4">{error}</div>}
        
        <form onSubmit={handleSetup} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Enrollment Code</label>
            <input type="text" required placeholder="Provided by us" value={enrollmentCode} onChange={(e) => setEnrollmentCode(e.target.value)} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Admin Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Admin Password</label>
            <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none" />
          </div>
          <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition font-medium">Create School & Admin</button>
        </form>
      </div>
    </div>
  );
}

function Login({ onLogin, school, onBack }: { onLogin: (user: any) => void, school: any, onBack: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ school_id: school.id, email, password }),
      });
      if (res.ok) {
        const data = await res.json();
        onLogin(data.user);
      } else {
        setError('Invalid email or password');
      }
    } catch (error) {
      setError('Network error. Please try again.');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-md">
        <button onClick={onBack} className="text-gray-400 hover:text-gray-600 mb-4 flex items-center gap-1 text-sm">
          <ArrowLeft size={16} /> Change School
        </button>
        <div className="flex justify-center mb-6">
          {school.logo_url ? (
            <img src={school.logo_url} alt="Logo" className="w-20 h-20 object-contain rounded-xl" />
          ) : (
            <div className="w-16 h-16 bg-indigo-100 text-indigo-600 flex items-center justify-center rounded-full">
              <School size={32} />
            </div>
          )}
        </div>
        <h2 className="text-2xl font-bold text-center mb-2">{school.name}</h2>
        <p className="text-gray-500 text-center mb-6">Sign in to your account</p>
        
        {error && <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm mb-4">{error}</div>}
        
        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none" />
          </div>
          <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition font-medium">Sign In</button>
        </form>
      </div>
    </div>
  );
}

function AdminDashboard({ school, setSchool, user }: { school: any, setSchool: (s: any) => void, user: any }) {
  const [activeTab, setActiveTab] = useState('families');

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="flex border-b border-gray-100">
        <button onClick={() => setActiveTab('families')} className={`flex-1 py-4 font-medium text-sm flex items-center justify-center gap-2 ${activeTab === 'families' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}>
          <Users size={18} /> Families
        </button>
        <button onClick={() => setActiveTab('guards')} className={`flex-1 py-4 font-medium text-sm flex items-center justify-center gap-2 ${activeTab === 'guards' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}>
          <Shield size={18} /> Guards
        </button>
        <button onClick={() => setActiveTab('settings')} className={`flex-1 py-4 font-medium text-sm flex items-center justify-center gap-2 ${activeTab === 'settings' ? 'text-indigo-600 border-b-2 border-indigo-600' : 'text-gray-500 hover:text-gray-700'}`}>
          <Settings size={18} /> Settings
        </button>
      </div>
      <div className="p-6">
        {activeTab === 'families' && <AdminFamilies school={school} />}
        {activeTab === 'guards' && <AdminGuards school={school} />}
        {activeTab === 'settings' && <AdminSettings school={school} setSchool={setSchool} user={user} />}
      </div>
    </div>
  );
}

function AdminFamilies({ school }: { school: any }) {
  const [families, setFamilies] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [familyName, setFamilyName] = useState('');
  const [parentEmail, setParentEmail] = useState('');
  const [parentPassword, setParentPassword] = useState('');
  
  const [studentName, setStudentName] = useState('');
  const [studentClass, setStudentClass] = useState('');
  const [studentSection, setStudentSection] = useState('');
  const [selectedFamilyId, setSelectedFamilyId] = useState('');

  useEffect(() => {
    fetchFamilies();
    fetchStudents();
  }, [school.id]);

  const fetchFamilies = () => {
    fetch(`/api/families?school_id=${school.id}`).then(res => res.json()).then(setFamilies);
  };

  const fetchStudents = () => {
    fetch(`/api/students?school_id=${school.id}`).then(res => res.json()).then(setStudents);
  };

  const handleCreateFamily = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/families', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ school_id: school.id, familyName, parentEmail, parentPassword }),
      });
      if (res.ok) {
        setFamilyName(''); setParentEmail(''); setParentPassword('');
        fetchFamilies();
      } else {
        console.error('Failed to create family');
      }
    } catch (error) {
      console.error('Network error. Please try again.');
    }
  };

  const handleAddStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedFamilyId) return;
    try {
      const res = await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ school_id: school.id, name: studentName, family_id: selectedFamilyId, class_name: studentClass, section: studentSection }),
      });
      if (res.ok) {
        setStudentName(''); setStudentClass(''); setStudentSection('');
        fetchStudents();
      } else {
        console.error('Failed to add student');
      }
    } catch (error) {
      console.error('Network error. Please try again.');
    }
  };

  const handleDeleteFamily = async (id: number) => {
    try {
      const res = await fetch(`/api/families/${id}`, { method: 'DELETE' });
      if (res.ok) {
        fetchFamilies();
        fetchStudents();
      } else {
        console.error('Failed to delete family');
      }
    } catch (error) {
      console.error('Network error. Please try again.');
    }
  };

  const handleDeleteStudent = async (id: number) => {
    try {
      const res = await fetch(`/api/students/${id}`, { method: 'DELETE' });
      if (res.ok) {
        fetchStudents();
      } else {
        console.error('Failed to delete student');
      }
    } catch (error) {
      console.error('Network error. Please try again.');
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-lg font-semibold mb-4">Create Family & Parent</h3>
        <form onSubmit={handleCreateFamily} className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <input type="text" placeholder="Family Name (e.g. Smith)" required value={familyName} onChange={e => setFamilyName(e.target.value)} className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
          <input type="email" placeholder="Parent Email" required value={parentEmail} onChange={e => setParentEmail(e.target.value)} className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
          <input type="password" placeholder="Parent Password" required value={parentPassword} onChange={e => setParentPassword(e.target.value)} className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
          <button type="submit" className="md:col-span-3 bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition font-medium">Create Family</button>
        </form>
      </div>

      <div className="pt-6 border-t border-gray-100">
        <h3 className="text-lg font-semibold mb-4">Add Student to Family</h3>
        <form onSubmit={handleAddStudent} className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <select required value={selectedFamilyId} onChange={e => setSelectedFamilyId(e.target.value)} className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none bg-white md:col-span-1">
            <option value="">Select Family</option>
            {families.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
          </select>
          <input type="text" placeholder="Student Name" required value={studentName} onChange={e => setStudentName(e.target.value)} className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none md:col-span-1" />
          <input type="text" placeholder="Class (e.g. 5)" required value={studentClass} onChange={e => setStudentClass(e.target.value)} className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none md:col-span-1" />
          <input type="text" placeholder="Section (e.g. A)" required value={studentSection} onChange={e => setStudentSection(e.target.value)} className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none md:col-span-1" />
          <button type="submit" className="bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition font-medium md:col-span-1">Add Student</button>
        </form>
      </div>

      <div className="pt-6 border-t border-gray-100">
        <h3 className="text-lg font-semibold mb-4">Manage Families & Students</h3>
        <div className="space-y-4">
          {families.length === 0 && <p className="text-gray-500">No families created yet.</p>}
          {families.map(family => {
            const familyStudents = students.filter(s => s.family_id === family.id);
            return (
              <div key={family.id} className="bg-gray-50 p-4 rounded-xl border border-gray-200">
                <div className="flex justify-between items-center mb-3">
                  <h4 className="font-semibold text-lg flex items-center gap-2">
                    <Users size={18} className="text-indigo-600" />
                    {family.name} Family
                  </h4>
                  <button onClick={() => handleDeleteFamily(family.id)} className="text-red-500 hover:text-red-700 text-sm font-medium">
                    Delete Family
                  </button>
                </div>
                
                {familyStudents.length > 0 ? (
                  <div className="space-y-2 mt-2">
                    {familyStudents.map(student => (
                      <div key={student.id} className="bg-white p-3 rounded-lg border border-gray-100 flex justify-between items-center shadow-sm">
                        <div>
                          <span className="font-medium">{student.name}</span>
                          {student.class_name && (
                            <span className="text-gray-500 text-sm ml-3">Class: {student.class_name} | Section: {student.section}</span>
                          )}
                        </div>
                        <button onClick={() => handleDeleteStudent(student.id)} className="text-red-400 hover:text-red-600 text-sm">
                          Remove
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-gray-500 italic mt-2">No students added yet.</p>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function AdminGuards({ school }: { school: any }) {
  const [guards, setGuards] = useState<any[]>([]);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  useEffect(() => {
    fetchGuards();
  }, [school.id]);

  const fetchGuards = () => {
    fetch(`/api/guards?school_id=${school.id}`).then(res => res.json()).then(setGuards);
  };

  const handleCreateGuard = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/guards', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ school_id: school.id, email, password }),
      });
      if (res.ok) {
        setEmail(''); setPassword('');
        fetchGuards();
      } else {
        console.error('Failed to create guard');
      }
    } catch (error) {
      console.error('Network error. Please try again.');
    }
  };

  const handleDeleteGuard = async (id: number) => {
    try {
      const res = await fetch(`/api/guards/${id}`, { method: 'DELETE' });
      if (res.ok) {
        fetchGuards();
      } else {
        console.error('Failed to delete guard');
      }
    } catch (error) {
      console.error('Network error. Please try again.');
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-lg font-semibold mb-4">Create Guard Account</h3>
        <form onSubmit={handleCreateGuard} className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input type="email" placeholder="Guard Email" required value={email} onChange={e => setEmail(e.target.value)} className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
          <input type="password" placeholder="Guard Password" required value={password} onChange={e => setPassword(e.target.value)} className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
          <button type="submit" className="md:col-span-2 bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition font-medium">Create Guard</button>
        </form>
      </div>

      <div className="pt-6 border-t border-gray-100">
        <h3 className="text-lg font-semibold mb-4">Manage Guards</h3>
        <div className="space-y-3">
          {guards.length === 0 && <p className="text-gray-500">No guards created yet.</p>}
          {guards.map(guard => (
            <div key={guard.id} className="bg-gray-50 p-4 rounded-xl border border-gray-200 flex justify-between items-center">
              <div className="flex items-center gap-3">
                <Shield size={18} className="text-indigo-600" />
                <span className="font-medium">{guard.email}</span>
              </div>
              <button onClick={() => handleDeleteGuard(guard.id)} className="text-red-500 hover:text-red-700 text-sm font-medium">
                Delete
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AdminSettings({ school, setSchool, user }: { school: any, setSchool: (s: any) => void, user: any }) {
  const [logoUrl, setLogoUrl] = useState(school.logo_url || '');
  const [isUploading, setIsUploading] = useState(false);
  
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordMessage, setPasswordMessage] = useState('');

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ school_id: school.id, logo_url: logoUrl }),
      });
      if (res.ok) {
        setSchool({ ...school, logo_url: logoUrl });
        alert('Settings saved!');
      } else {
        alert('Failed to save settings');
      }
    } catch (error) {
      alert('Network error. Please try again.');
    }
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordMessage('');
    if (newPassword !== confirmPassword) {
      setPasswordMessage('New passwords do not match');
      return;
    }
    try {
      const res = await fetch('/api/admin/password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, currentPassword, newPassword }),
      });
      if (res.ok) {
        setPasswordMessage('Password updated successfully!');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        const data = await res.json();
        setPasswordMessage(data.error || 'Failed to update password');
      }
    } catch (error) {
      setPasswordMessage('Network error. Please try again.');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert('File is too large. Maximum size is 5MB.');
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onloadend = () => {
      setLogoUrl(reader.result as string);
      setIsUploading(false);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-10">
      <div>
        <h3 className="text-lg font-semibold mb-4">School Settings</h3>
        <form onSubmit={handleSave} className="space-y-4 max-w-md">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">School Logo</label>
            <div className="flex items-center gap-4">
              {logoUrl && (
                <img src={logoUrl} alt="Logo Preview" className="w-16 h-16 object-contain border border-gray-200 rounded-lg bg-gray-50" />
              )}
              <div className="flex-1">
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={handleFileUpload} 
                  className="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer" 
                />
                {isUploading && <p className="text-xs text-gray-500 mt-1">Processing image...</p>}
              </div>
            </div>
          </div>
          <button type="submit" className="w-full bg-indigo-600 text-white py-2 rounded-lg hover:bg-indigo-700 transition font-medium">Save Settings</button>
        </form>
      </div>

      <div className="pt-8 border-t border-gray-100">
        <h3 className="text-lg font-semibold mb-4">Change Admin Password</h3>
        <form onSubmit={handlePasswordChange} className="space-y-4 max-w-md">
          {passwordMessage && (
            <div className={`p-3 rounded-lg text-sm ${passwordMessage.includes('success') ? 'bg-emerald-50 text-emerald-700' : 'bg-red-50 text-red-600'}`}>
              {passwordMessage}
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
            <input type="password" required value={currentPassword} onChange={e => setCurrentPassword(e.target.value)} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">New Password</label>
            <input type="password" required value={newPassword} onChange={e => setNewPassword(e.target.value)} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
            <input type="password" required value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none" />
          </div>
          <button type="submit" className="w-full bg-gray-900 text-white py-2 rounded-lg hover:bg-gray-800 transition font-medium">Update Password</button>
        </form>
      </div>
    </div>
  );
}

function ParentDashboard({ user, school }: { user: any, school: any }) {
  const [students, setStudents] = useState<any[]>([]);

  const fetchStudents = () => {
    fetch(`/api/parent/students?family_id=${user.family_id}`).then(res => res.json()).then(setStudents);
  };

  useEffect(() => {
    socket.emit('join_school', school.id);
    fetchStudents();
    socket.on('student_updated', fetchStudents);
    return () => { socket.off('student_updated', fetchStudents); };
  }, [user.family_id, school.id]);

  const handleCall = (studentId: number) => {
    socket.emit('call_student', { studentId, schoolId: school.id });
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Your Children</h2>
      <div className="grid gap-4">
        {students.length === 0 && <p className="text-gray-500">No children assigned to your family yet.</p>}
        {students.map(student => (
          <div key={student.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center">
                <User size={24} />
              </div>
              <div>
                <h3 className="font-semibold text-lg">{student.name}</h3>
                {student.class_name && <p className="text-sm text-gray-600 mb-1">Class: {student.class_name} | Section: {student.section}</p>}
                <p className="text-sm text-gray-500">
                  Status: <span className={student.status === 'called' ? 'text-amber-600 font-medium' : 'text-gray-500'}>{student.status === 'called' ? 'Called for Pickup' : 'Idle'}</span>
                </p>
              </div>
            </div>
            <button 
              onClick={() => handleCall(student.id)}
              disabled={student.status === 'called'}
              className={`flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition ${
                student.status === 'called' 
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                  : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm'
              }`}
            >
              <Phone size={18} />
              {student.status === 'called' ? 'Called' : 'Call'}
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

function GuardDashboard({ school }: { school: any }) {
  const [calledStudents, setCalledStudents] = useState<any[]>([]);

  const fetchCalledStudents = () => {
    fetch(`/api/guard/students?school_id=${school.id}`).then(res => res.json()).then(setCalledStudents);
  };

  useEffect(() => {
    socket.emit('join_school', school.id);
    fetchCalledStudents();
    socket.on('student_updated', fetchCalledStudents);
    return () => { socket.off('student_updated', fetchCalledStudents); };
  }, [school.id]);

  const handleDismiss = (studentId: number) => {
    socket.emit('dismiss_student', { studentId, schoolId: school.id });
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
        <Shield className="text-indigo-600" /> Active Pickups
      </h2>
      <div className="grid gap-4">
        {calledStudents.length === 0 && (
          <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 text-center">
            <div className="w-16 h-16 bg-gray-50 text-gray-400 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle size={32} />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-1">All Clear</h3>
            <p className="text-gray-500">No students are currently called for pickup.</p>
          </div>
        )}
        {calledStudents.map(student => (
          <div key={student.id} className="bg-white p-6 rounded-xl shadow-sm border border-amber-200 bg-amber-50/30 flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center">
                <User size={24} />
              </div>
              <div>
                <h3 className="font-semibold text-lg">{student.name}</h3>
                {student.class_name && <p className="text-sm text-amber-800 mb-1">Class: {student.class_name} | Section: {student.section}</p>}
                <p className="text-sm text-amber-700 font-medium">Parent is waiting</p>
              </div>
            </div>
            <button 
              onClick={() => handleDismiss(student.id)}
              className="flex items-center gap-2 px-6 py-3 rounded-lg font-medium bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm transition"
            >
              <CheckCircle size={18} />
              Done
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
