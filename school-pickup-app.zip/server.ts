import express from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const dbPath = process.env.NODE_ENV === 'production' 
  ? '/tmp/school_pickup_v2.db' 
  : 'school_pickup_v2.db';
const db = new Database(dbPath);

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS schools (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    logo_url TEXT
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL,
    email TEXT NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL,
    family_id INTEGER,
    UNIQUE(school_id, email)
  );

  CREATE TABLE IF NOT EXISTS families (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL,
    name TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    school_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    family_id INTEGER NOT NULL,
    class_name TEXT,
    section TEXT,
    status TEXT DEFAULT 'idle'
  );

  CREATE TABLE IF NOT EXISTS enrollment_codes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT UNIQUE NOT NULL,
    is_used INTEGER DEFAULT 0
  );
`);

try { db.exec("ALTER TABLE students ADD COLUMN class_name TEXT"); } catch (e) {}
try { db.exec("ALTER TABLE students ADD COLUMN section TEXT"); } catch (e) {}

// Generate 1000 enrollment codes if none exist
const codeCount = db.prepare('SELECT COUNT(*) as count FROM enrollment_codes').get() as { count: number };
if (codeCount.count === 0) {
  const codes = new Set<string>();
  while(codes.size < 1000) {
     codes.add('SCH-' + Math.random().toString(36).substring(2, 6).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase());
  }
  const insert = db.prepare('INSERT INTO enrollment_codes (code) VALUES (?)');
  db.transaction(() => {
    for (const code of codes) {
      insert.run(code);
    }
  })();
  fs.writeFileSync('enrollment_codes.txt', Array.from(codes).join('\n'));
  console.log('Generated 1000 enrollment codes and saved to enrollment_codes.txt');
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  const io = new Server(server, {
    cors: {
      origin: '*',
    },
  });
  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // API Routes

  // Check if school exists
  app.post('/api/school/check', (req, res) => {
    const { name } = req.body;
    const school = db.prepare('SELECT * FROM schools WHERE name = ? COLLATE NOCASE').get(name);
    if (school) {
      res.json({ exists: true, school });
    } else {
      res.json({ exists: false });
    }
  });

  // Setup school and admin
  app.post('/api/school/setup', (req, res) => {
    const { schoolName, email, password, enrollmentCode } = req.body;
    
    const codeRecord = db.prepare('SELECT * FROM enrollment_codes WHERE code = ?').get(enrollmentCode) as any;
    
    if (!codeRecord) {
      return res.status(403).json({ error: 'Invalid Enrollment Code' });
    }
    
    if (codeRecord.is_used === 1) {
      return res.status(403).json({ error: 'Used Code. Error.' });
    }

    try {
      let school = db.prepare('SELECT * FROM schools WHERE name = ? COLLATE NOCASE').get(schoolName);
      if (school) {
        return res.status(400).json({ error: 'School already exists' });
      }

      db.transaction(() => {
        const info = db.prepare('INSERT INTO schools (name, logo_url) VALUES (?, ?)').run(schoolName, '');
        const schoolId = info.lastInsertRowid;
        db.prepare('INSERT INTO users (school_id, email, password, role) VALUES (?, ?, ?, ?)').run(schoolId, email, password, 'admin');
        db.prepare('UPDATE enrollment_codes SET is_used = 1 WHERE id = ?').run(codeRecord.id);
      })();
      
      school = db.prepare('SELECT * FROM schools WHERE name = ?').get(schoolName);
      res.json({ success: true, school });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to create school' });
    }
  });

  // Login
  app.post('/api/login', (req, res) => {
    const { school_id, email, password } = req.body;
    const user = db.prepare('SELECT * FROM users WHERE school_id = ? AND email = ? AND password = ?').get(school_id, email, password) as any;
    
    if (user) {
      // Don't send password back
      const { password: _, ...userWithoutPassword } = user;
      res.json({ user: userWithoutPassword });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  });

  // Update settings (logo)
  app.post('/api/settings', (req, res) => {
    const { school_id, logo_url } = req.body;
    db.prepare('UPDATE schools SET logo_url = ? WHERE id = ?').run(logo_url, school_id);
    res.json({ success: true });
  });

  // Change admin password
  app.post('/api/admin/password', (req, res) => {
    const { userId, currentPassword, newPassword } = req.body;
    
    try {
      // Verify current password
      const user = db.prepare('SELECT * FROM users WHERE id = ? AND password = ?').get(userId, currentPassword);
      
      if (!user) {
        return res.status(401).json({ error: 'Incorrect current password' });
      }

      // Update password
      db.prepare('UPDATE users SET password = ? WHERE id = ?').run(newPassword, userId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update password' });
    }
  });

  // Admin: Create family and parent
  app.post('/api/families', (req, res) => {
    const { school_id, familyName, parentEmail, parentPassword } = req.body;
    
    try {
      db.transaction(() => {
        const info = db.prepare('INSERT INTO families (school_id, name) VALUES (?, ?)').run(school_id, familyName);
        const familyId = info.lastInsertRowid;
        db.prepare('INSERT INTO users (school_id, email, password, role, family_id) VALUES (?, ?, ?, ?, ?)').run(school_id, parentEmail, parentPassword, 'parent', familyId);
      })();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to create family or parent' });
    }
  });

  // Admin: Add student to family
  app.post('/api/students', (req, res) => {
    const { school_id, name, family_id, class_name, section } = req.body;
    try {
      db.prepare('INSERT INTO students (school_id, name, family_id, class_name, section) VALUES (?, ?, ?, ?, ?)').run(school_id, name, family_id, class_name, section);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to add student' });
    }
  });

  // Admin: Delete student
  app.delete('/api/students/:id', (req, res) => {
    try {
      db.prepare('DELETE FROM students WHERE id = ?').run(Number(req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete student' });
    }
  });

  // Admin: Delete family
  app.delete('/api/families/:id', (req, res) => {
    try {
      const familyId = Number(req.params.id);
      db.transaction(() => {
        // Delete all students associated with the family
        db.prepare('DELETE FROM students WHERE family_id = ?').run(familyId);
        // Delete all users (parents) associated with the family
        db.prepare('DELETE FROM users WHERE family_id = ?').run(familyId);
        // Delete the family itself
        db.prepare('DELETE FROM families WHERE id = ?').run(familyId);
      })();
      res.json({ success: true });
    } catch (error) {
      console.error('Error deleting family:', error);
      res.status(500).json({ error: 'Failed to delete family' });
    }
  });

  // Admin: Add guard
  app.post('/api/guards', (req, res) => {
    const { school_id, email, password } = req.body;
    try {
      db.prepare('INSERT INTO users (school_id, email, password, role) VALUES (?, ?, ?, ?)').run(school_id, email, password, 'guard');
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to create guard' });
    }
  });

  // Admin: Get all guards
  app.get('/api/guards', (req, res) => {
    const { school_id } = req.query;
    const guards = db.prepare('SELECT id, email FROM users WHERE school_id = ? AND role = ?').all(school_id, 'guard');
    res.json(guards);
  });

  // Admin: Delete guard
  app.delete('/api/guards/:id', (req, res) => {
    try {
      db.prepare('DELETE FROM users WHERE id = ? AND role = ?').run(Number(req.params.id), 'guard');
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to delete guard' });
    }
  });

  // Get all families for a school
  app.get('/api/families', (req, res) => {
    const { school_id } = req.query;
    const families = db.prepare('SELECT * FROM families WHERE school_id = ?').all(school_id);
    res.json(families);
  });

  // Get all students for a school
  app.get('/api/students', (req, res) => {
    const { school_id } = req.query;
    const students = db.prepare('SELECT * FROM students WHERE school_id = ?').all(school_id);
    res.json(students);
  });

  // Get parent's students
  app.get('/api/parent/students', (req, res) => {
    const { family_id } = req.query;
    if (!family_id) return res.status(400).json({ error: 'Missing family_id' });
    
    const students = db.prepare('SELECT * FROM students WHERE family_id = ?').all(family_id);
    res.json(students);
  });

  // Get called students for guard
  app.get('/api/guard/students', (req, res) => {
    const { school_id } = req.query;
    const students = db.prepare('SELECT * FROM students WHERE school_id = ? AND status = ?').all(school_id, 'called');
    res.json(students);
  });

  // Socket.io for real-time updates
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);

    // Join a room specific to the school
    socket.on('join_school', (schoolId) => {
      socket.join(`school_${schoolId}`);
    });

    socket.on('call_student', ({ studentId, schoolId }) => {
      db.prepare('UPDATE students SET status = ? WHERE id = ?').run('called', studentId);
      io.to(`school_${schoolId}`).emit('student_updated');
    });

    socket.on('dismiss_student', ({ studentId, schoolId }) => {
      db.prepare('UPDATE students SET status = ? WHERE id = ?').run('idle', studentId);
      io.to(`school_${schoolId}`).emit('student_updated');
    });

    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist/index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
